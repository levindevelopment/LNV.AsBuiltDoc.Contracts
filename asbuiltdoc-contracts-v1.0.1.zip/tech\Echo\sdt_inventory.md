# Echo SDT Inventory

Echo is a harness collector and does not define SDT tags.
