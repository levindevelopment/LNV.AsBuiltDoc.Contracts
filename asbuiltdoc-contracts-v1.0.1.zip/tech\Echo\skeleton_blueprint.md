# Echo Skeleton Blueprint

Echo is a harness collector and has no document skeleton.
